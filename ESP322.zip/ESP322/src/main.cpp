#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "ESP32-AccessPoint"; // Erişim noktası adı
const char* password = "password123"; // Erişim noktası şifresi

WebServer server(80); // Web sunucusu 80 portundan çalışacak

String selectedSSID; // Seçilen ağın SSID'sini saklar

void handleRoot() {
  String htmlContent = 
  "<!DOCTYPE html>\n"
  "<html lang=\"en\">\n"
  "<head>\n"
  "  <meta charset=\"UTF-8\">\n"
  "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
  "  <title>WiFi Tarama</title>\n"
  "  <script>\n"
  "    function connectToNetwork(ssid) {\n"
  "      var password = prompt('Şifre girin:');\n"
  "      if (password != null) {\n"
  "        var xhr = new XMLHttpRequest();\n"
  "        xhr.open('POST', '/connect', true);\n"
  "        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');\n"
  "        xhr.onreadystatechange = function() {\n"
  "          if (xhr.readyState == 4) {\n"
  "            if (xhr.status == 200) {\n"
  "              alert('Bağlantı başarılı!');\n"
  "            } else {\n"
  "              alert('Bağlantı başarısız! ' + xhr.responseText);\n"
  "            }\n"
  "          }\n"
  "        };\n"
  "        xhr.send('ssid=' + ssid + '&password=' + password);\n"
  "      }\n"
  "    }\n"
  "  </script>\n"
  "</head>\n"
  "<body>\n"
  "  <h1>Etraftaki WiFi Ağları</h1>\n"
  "  <ul>\n";

  int numNetworks = WiFi.scanNetworks();
  for (int i = 0; i < numNetworks; i++) {
    htmlContent += "    <li><button type=\"button\" onclick=\"connectToNetwork('" + WiFi.SSID(i) + "')\">" + WiFi.SSID(i) + "</button></li>\n";
  }

  htmlContent += 
  "  </ul>\n"
  "</body>\n"
  "</html>\n";

  server.send(200, "text/html", htmlContent);
}

void handleConnect() {
  selectedSSID = server.arg("ssid");
  String password = server.arg("password");

  Serial.print("Bağlanmaya çalışılan ağ: ");
  Serial.println(selectedSSID);
  
  WiFi.begin(selectedSSID.c_str(), password.c_str());

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 10) {
    delay(1000);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nBağlantı başarılı!");
    server.send(200, "text/plain", "Bağlantı başarılı!");
  } else {
    Serial.println("\nBağlantı başarısız!");
    server.send(500, "text/plain", "Bağlantı başarısız!");
  }
}

void setup() {
  Serial.begin(115200);

  WiFi.softAP(ssid, password);
  
  IPAddress IP = WiFi.softAPIP();
  Serial.print("Erişim noktası IP adresi: ");
  Serial.println(IP);

  server.on("/", HTTP_GET, handleRoot);
  server.on("/connect", HTTP_POST, handleConnect);

  server.begin();
}

void loop() {
  server.handleClient();
}
